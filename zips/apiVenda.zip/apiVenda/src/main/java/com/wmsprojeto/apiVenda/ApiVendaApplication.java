package com.wmsprojeto.apiVenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiVendaApplication.class, args);
	}

}
