package com.wmsprojeto.apiVenda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
